(() => {
  const sample = new Uint8Array(4);
  const observed = new WeakSet();
  const records = {graphics: [], clicks: [], pointerUps: [], minerSamples: [], lifecycle: [], errors: []};
  const getContext = HTMLCanvasElement.prototype.getContext;
  HTMLCanvasElement.prototype.getContext = function (...args) {
    const gl = Reflect.apply(getContext, this, args);
    if (!gl || !/^(webgl2?|experimental-webgl)$/.test(args[0]) || observed.has(gl)) return gl;
    observed.add(gl);
    const row = {draws: 0, latest: null};
    records.graphics.push(row);
    let observedAt = -1000;
    for (const method of ['drawElements', 'drawArrays', 'drawElementsInstanced', 'drawArraysInstanced']) {
      const draw = gl[method];
      if (typeof draw !== 'function') continue;
      gl[method] = function (...params) {
        const result = Reflect.apply(draw, this, params);
        row.draws++;
        if (performance.now() - observedAt < 420 || gl.getParameter(gl.FRAMEBUFFER_BINDING) !== null) return result;
        observedAt = performance.now();
        queueMicrotask(() => {
          try {
            const width = gl.drawingBufferWidth, height = gl.drawingBufferHeight;
            if (!width || !height || gl.isContextLost() || gl.getParameter(gl.FRAMEBUFFER_BINDING) !== null) return;
            const colors = new Set();
            for (const x of [.20, .34, .5, .66, .80]) for (const y of [.2, .35, .52, .65, .82]) {
              gl.readPixels(Math.round(x * (width - 1)), Math.round(y * (height - 1)), 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, sample);
              colors.add([...sample].join(','));
            }
            const program = gl.getParameter(gl.CURRENT_PROGRAM);
            row.latest = {width, height, canvas: gl.canvas.id, colors: [...colors],
                          draw: row.draws, time: performance.now(),
                          link: program ? gl.getProgramParameter(program, gl.LINK_STATUS) : false};
          } catch (error) { records.errors.push(String(error)); }
        });
        return result;
      };
    }
    return gl;
  };
  document.addEventListener('click', event => {
    records.clicks.push({target: event.target, trusted: event.isTrusted,
                         activation: navigator.userActivation?.isActive === true});
  }, true);
  document.addEventListener('pointerup', event => {
    records.pointerUps.push({target: event.target, trusted: event.isTrusted});
  }, true);
  document.addEventListener('visibilitychange', () => {
    records.lifecycle.push(document.visibilityState);
  });
  if (window.AudioBufferSourceNode) {
    const start = AudioBufferSourceNode.prototype.start;
    AudioBufferSourceNode.prototype.start = function (...args) {
      const audio = window.MINER?.SFX136;
      const entry = Object.entries(audio?.samples ?? {}).find(([, value]) => value === this.buffer);
      if (entry) {
        const cue = {name: entry[0], context: this.context.state, gain: audio.out.gain.value, ended: false, peak: 0};
        const signal = this.context.createAnalyser();
        const silent = this.context.createGain();
        silent.gain.value = 0;
        this.connect(signal);
        signal.connect(silent);
        silent.connect(this.context.destination);
        const values = new Float32Array(signal.fftSize);
        const timer = setInterval(() => {
          signal.getFloatTimeDomainData(values);
          for (const value of values) cue.peak = Math.max(cue.peak, Math.abs(value));
        }, 12);
        this.addEventListener('ended', () => {
          cue.ended = true;
          clearInterval(timer);
          signal.disconnect();
          silent.disconnect();
        }, {once: true});
        records.minerSamples.push(cue);
      }
      return Reflect.apply(start, this, args);
    };
  }
  window.__appleNativeObserver = records;
})();
