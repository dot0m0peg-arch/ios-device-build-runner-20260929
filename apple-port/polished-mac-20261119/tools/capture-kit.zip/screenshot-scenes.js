(() => {
  const delay = time => new Promise(resolve => setTimeout(resolve, time));
  function shown(selector) {
    return [...document.querySelectorAll(selector)].find(el => el.getClientRects().length && !el.disabled);
  }
  async function wait(label, ready, timeout = 28000) {
    const until = performance.now() + timeout;
    do {
      if (ready()) return;
      await delay(100);
    } while (performance.now() < until);
    throw new Error('Screenshot scene did not reach ' + label);
  }
  async function click(selector) {
    await wait(selector, () => shown(selector));
    shown(selector).click();
  }
  function key(target, event, k, code) {
    target.dispatchEvent(new KeyboardEvent(event, {key: k, code, bubbles: true, cancelable: true}));
  }
  async function placeLog(lastArrow = null) {
    await click('#logs button.log[data-size="4"]');
    const board = document.querySelector('#surface canvas');
    if (lastArrow) key(board, 'keydown', lastArrow, lastArrow);
    key(board, 'keydown', 'Enter', 'Enter');
    key(board, 'keydown', 'Escape', 'Escape');
  }
  const scenes = {
    async MyPetSnake(frame) {
      await wait('first frame', () => window.sb?.ready && window.sb.breeding && !document.querySelector('#splash'));
      if (frame === 1) {
        if (localStorage.getItem('my-pet-snake.tutorial.v1') !== 'seen') await click('[data-st-skip]');
        window.sb.room.enterTank('starter');
        await click('[data-pet-action="mode"][data-pet-value="bunny"]');
      }
      const breed = ['dutch', 'lop', 'rex'][frame - 1];
      await click('[data-pet-action="rabbit"][data-pet-value="' + breed + '"]');
      await wait('rendered ' + breed, () => {
        const model = window.sb.scene.getObjectByName('Bunny');
        return model?.visible && model.userData?.breed === breed && model.userData?.source === 'tripo';
      });
      return breed;
    },
    async Timbersack(frame) {
      if (frame === 1) {
        await click('#openSack');
        await placeLog();
        await wait('placed log', () => document.querySelector('#pieceCount')?.textContent === '1 on board');
        return 'long-log';
      }
      await click('#sceneryTab');
      await click('#sceneryPieces button.log[data-size="7"]');
      const board = document.querySelector('#surface canvas');
      for (let i = 0; i < 5; i++) key(board, 'keydown', 'ArrowRight', 'ArrowRight');
      key(board, 'keydown', 'Enter', 'Enter');
      key(board, 'keydown', 'Escape', 'Escape');
      return 'scenery-tray';
    },
    async LastCarUpright(frame) {
      if (frame === 1) {
        await click('[data-a=h2h]');
        await click('[data-a=go]');
        await click('[data-a=go]');
        await wait('aim phase', () => window.LCU?.api?.smashState().mode === 'h2hAim');
        return 'head-to-head';
      }
      window.LCU.api.setAim(0, 0);
      window.LCU.api.smashNow(.85);
      await wait('Head to Head result', () => window.LCU.api.smashState().mode === 'h2hOver');
      window.appleScreenshotH2HPlayed = true;
      window.LCU.api.toTitle();
      await click('[data-a=garage]');
      await wait('Garage car preview', () => shown('[data-a=fav]'));
      return 'garage';
    },
    async Miner3D(frame) {
      if (frame === 1) {
        await click('#tPlay');
        await wait('valley view', () => document.querySelector('#title')?.hidden && shown('#c3') && shown('#bView'));
        await delay(1700);
        return 'valley';
      }
      await click('#bView');
      await delay(800);
      return 'building-view';
    },
    async QuicksilverPennies(frame) {
      if (frame === 1) {
        await wait('workshop startup', () => window.qs?.state && shown('#play'));
        await click('#play');
        for (let i = 0; i < 3 && window.qs.state().phase === 'opening'; i++) await click('#opening');
        await wait('workshop controls', () => window.qs.state().phase === 'play');
        window.qs.debug.setJar(12);
        await click('#to-bench');
        await wait('jar at bench', () => window.qs.state().station === 'bench' && window.qs.state().jarAt === 'bench');
        await click('#jar-icon');
        await wait('pour reached the tray', () => window.qs.state().trayMl > .3);
        return 'pour';
      }
      await click('#jar-icon');
      await wait('workbench silver pool', () => window.qs.state().trayMl > .3);
      return 'silver-pool';
    }
  };
  window.appleScreenshotScene = (app, n) => scenes[app](n);
})();


