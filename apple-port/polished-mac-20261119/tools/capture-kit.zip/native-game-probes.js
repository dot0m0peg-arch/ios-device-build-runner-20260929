(() => {
  const timeline = {screens: [], audio: {}, checks: {}};
  const sleep = time => new Promise(resolve => setTimeout(resolve, time));
  const observer = window.__appleNativeObserver;
  const baseState = window.appleScreenshotState;
  const shown = selector => [...document.querySelectorAll(selector)]
    .find(element => element.getClientRects().length && !element.disabled);
  function require(ok, description) { if (!ok) throw new Error(description); }
  async function wait(description, check, duration = 25000) {
    const end = performance.now() + duration;
    do {
      const value = check();
      if (value) return value;
      await sleep(80);
    } while (performance.now() < end);
    throw new Error('Native acceptance timed out: ' + description);
  }
  async function tap(selector, hold = 0) {
    const target = await wait(selector, () => shown(selector));
    const bounds = target.getBoundingClientRect();
    const [x, y] = [bounds.x + bounds.width / 2, bounds.y + bounds.height / 2];
    require(target.contains(document.elementFromPoint(x, y)), 'Occluded game control: ' + selector);
    const events = hold ? observer.pointerUps : observer.clicks;
    const before = events.length;
    await window.webkit.messageHandlers.nativeMouse.postMessage({x, y, width: innerWidth, height: innerHeight, hold});
    return wait('trusted native input on ' + selector, () =>
      events.slice(before).find(event => event.trusted &&
        (event.target === target || target.contains(event.target))), 4000);
  }
  async function pixels(label, since, canvas) {
    const current = await wait(label + ' draws visible, non-flat default framebuffer', () =>
      observer.graphics.map(record => record.latest).find(frame =>
        frame?.link && frame.canvas === canvas && frame.width >= 320 && frame.height >= 240 &&
        frame.time > since && frame.colors.length >= 4));
    timeline.screens.push({label, ...current});
    return label;
  }
  function mediaEvidence(el, id) {
    return {id, currentTime: el.currentTime, duration: el.duration, readyState: el.readyState,
            paused: el.paused, gain: el.volume, muted: el.muted, error: el.error?.code ?? null};
  }
  function isAdvancing(el) {
    return el && !el.paused && !el.muted && !el.error && el.volume > 0 && el.readyState >= 2 &&
      Number.isFinite(el.duration) && el.currentTime > .10;
  }

  async function lastCarClip(expected, channel) {
    return wait('native MP3 clock on ' + expected, () => {
      const voice = LCU.voices, state = voice.state(), el = voice.el;
      if (state.playing && state.channel === channel && state.cur?.url.endsWith(expected) &&
          el?.currentSrc === state.cur.url && isAdvancing(el)) {
        return {...mediaEvidence(el, expected), channel, played: state.played, skipped: state.skipped};
      }
    });
  }
  async function lastCarOpening() {
    const action = await tap('[data-a=garage]');
    require(action.activation, 'Garage tap did not unlock WebKit media activation');
    timeline.audio.chalk = await lastCarClip('/voices/chalk/c151954a5c6.mp3', 'menu');
    await tap('[data-a=prev]');
    timeline.audio.previousCar = await lastCarClip('/voices/gravel/cdf2bfa225e.mp3', 'menu');
    await tap('[data-a=prev]');
    timeline.audio.nextCar = await lastCarClip('/voices/recess/ca36171ddcf.mp3', 'menu');
    LCU.api.toTitle();
    await tap('[data-a=campaign]');
    timeline.audio.opening = await lastCarClip('/voices/narrator/cc3d0ece57f.mp3', 'story');
    const openingText = LCU.voices.state().cur.text;
    await tap('.cstory');
    const advanced = await wait('next authored story line plays', () => {
      const voice = LCU.voices, state = voice.state();
      return state.channel === 'story' && state.cur && state.cur.text !== openingText && isAdvancing(voice.el) &&
        mediaEvidence(voice.el, state.cur.id);
    });
    timeline.audio.advancedStory = advanced;
    await tap('[data-a=skip-story]');
    await wait('skip stops previous story MP3', () => LCU.voices.state().channel !== 'story');
    timeline.checks.storySkip = true;
    LCU.api.toTitle();
  }
  async function lastCarSettingsAndImport() {
    LCU.api.toTitle();
    await tap('[data-a=read-voices]');
    await wait('Read screen is speaking before mute', () => LCU.voices.state().channel === 'help' && LCU.voices.state().playing);
    await tap('[data-a=voices]');
    await wait('Voices off cancels playback', () => LCU.save.settings.voices === false &&
      !LCU.voices.state().cur && LCU.voices.state().remaining === 0);
    timeline.checks.muteStopsSpeech = true;
    await tap('[data-a=voices]');
    await tap('[data-a=read-voices]');
    await wait('new Read screen starts before backgrounding', () => LCU.voices.state().playing && LCU.voices.state().channel === 'help');
    const before = observer.lifecycle.length;
    await window.webkit.messageHandlers.nativeMouse.postMessage('background');
    await wait('real AppKit hide/show and WebKit narration cancellation', () => {
      const states = observer.lifecycle.slice(before);
      return states.includes('hidden') && states.at(-1) === 'visible' && !LCU.voices.state().cur;
    });
    timeline.checks.backgroundCancelsSpeech = observer.lifecycle.slice(before);
    await tap('[data-a=menu-voices]');
    require(LCU.save.settings.narration === false, 'Menu voice preference did not turn off');
    // Exercise the released import parser with a minimal in-memory profile
    // snapshot. The native open/save panel round trip has its own bridge test.
    const payload = new File([JSON.stringify(LCU.save)], 'Native QA profile.json', {type: 'application/json'});
    const imported = await LCU.garage.importProfile(payload);
    await tap('[data-a=profiles]');
    await tap('.prow[data-p="' + imported.id + '"] [data-do=use]');
    await wait('imported profile active with saved menu voice off',
      () => LCU.garage.activeProfile().id === imported.id && LCU.save.settings.narration === false);
    require(LCU.save.settings.voices === true, 'Independent voices preference changed through import');
    timeline.checks.profile = {id: imported.id, narration: false, voices: true, parser: 'shipping JSON profile import'};
    LCU.api.toTitle();
  }

  async function minerVoice(kind) {
    return wait('customer ' + kind + ' recording is advancing', () => {
      const voice = MINER.VOICE137, el = voice.el, cue = voice.cur;
      if (cue?.id === 'shipment-' + kind && el?.currentSrc.startsWith('data:audio/mpeg;base64,') && isAdvancing(el)) {
        return {...mediaEvidence(el, cue.id), character: cue.voice, subtitle: cue.text, encodedLength: el.currentSrc.length};
      }
    }, 35000);
  }
  async function minerOrder() {
    await tap('#goalPill');
    timeline.audio.ask = await minerVoice('ask');
    await wait('guided seam produced copper and played non-silent ore Foley', () => MINER.G.inv.copper >= 3 &&
      observer.minerSamples.some(cue => cue.name === 'ore' && cue.context === 'running' && cue.gain > 0 && cue.ended && cue.peak > .0005),
      65000);
    timeline.audio.ore = observer.minerSamples.find(cue => cue.name === 'ore' && cue.ended && cue.peak > .0005);
    await tap('#goalPill');
    const before = {cash: MINER.G.money, copper: MINER.G.inv.copper};
    await tap('#sheetBody [data-act="deliver"][data-i="0"]');
    require(MINER.G.money === before.cash + 61 && MINER.G.inv.copper === before.copper - 3,
      'First copper order did not deliver exactly three copper for 61 coins');
    timeline.audio.thanks = await minerVoice('thanks');
    require(timeline.audio.ask.character === timeline.audio.thanks.character, 'A different resident thanked for the order');
    timeline.audio.delivery = await wait('delivery Foley decoded and finished with non-silent samples', () =>
      observer.minerSamples.find(cue => cue.name === 'delivery' && cue.ended && cue.peak > .0005));
    timeline.checks.delivered = {coins: 61, copper: 3};
    if (shown('#sheetClose')) await tap('#sheetClose');
  }

  function minerProgress(world) {
    return {cash: world.money, copper: world.inv.copper || 0, orderDone: world.firstOrderDone === true};
  }
  function sameMinerProgress(left, right) {
    return left.cash === right.cash && left.copper === right.copper && left.orderDone === right.orderDone;
  }
  async function minerSaveState(prior) {
    const current = await baseState('Miner3D', prior);
    if (prior) {
      const restored = minerProgress(MINER.G);
      require(sameMinerProgress(restored, prior.order), 'Fresh Miner process lost saved wallet, copper or completed order');
      return {...current, order: restored, initialAudit: prior.audit};
    }
    const checkpoint = minerProgress(MINER.G);
    const saved = JSON.parse(localStorage.getItem('miner3.save'));
    require(checkpoint.orderDone && sameMinerProgress(checkpoint, minerProgress(saved)),
      'Normal Save now did not include the completed order and remaining wallet/copper');
    return {...current, order: checkpoint, audit: timeline};
  }

  window.appleScreenshotScene = async (app, frame) => {
    if (app === 'LastCarUpright') {
      if (frame === 1) {
        await lastCarOpening();
        await tap('[data-a=h2h]');
        await tap('[data-a=go]');
        await tap('[data-a=go]');
        await wait('Head to Head aim', () => LCU.api.smashState().mode === 'h2hAim');
        return pixels('head-to-head', performance.now(), 'view');
      }
      await tap('[data-a=hold]', 900);
      await wait('Head to Head results after real wind-up and release', () => LCU.api.smashState().mode === 'h2hOver');
      timeline.checks.nativeHeadToHead = true;
      window.appleScreenshotH2HPlayed = true;
      LCU.api.toTitle();
      await tap('[data-a=garage]');
      await wait('Garage car and favorite control', () => shown('[data-a=fav]'));
      return pixels('garage', performance.now(), 'view');
    }
    if (app === 'Miner3D') {
      if (frame === 1) {
        const entry = await tap('#tPlay');
        require(entry.activation, 'Play tap did not start within a trusted activation');
        timeline.audio.music = await wait('authentic track played from the local game bundle', () => {
          const el = window.MINER?.MUSIC136.el;
          return el?.currentSrc.includes('/music/') && isAdvancing(el) && mediaEvidence(el, el.currentSrc.split('/').at(-1));
        }, 35000);
        await wait('Miner valley playable', () => MINER.gameState === 'play' && MINER.mode === 'foot' && shown('#c3'));
        return pixels('valley', performance.now(), 'c3');
      }
      await minerOrder();
      return pixels('copper-order', performance.now(), 'c3');
    }
    throw new Error('Unexpected capture app');
  };

  window.appleScreenshotState = async (app, prior) => {
    if (app === 'LastCarUpright' && !prior) {
      await tap('[data-a=fav]');
      await lastCarSettingsAndImport();
      const favorite = Object.entries(LCU.save.cars).find(([, car]) => car.favorite)?.[0];
      require(favorite && window.appleScreenshotH2HPlayed, 'No persisted Garage favorite or completed match');
      require(LCU.voices.state().skipped.error === 0 && LCU.voices.state().skipped.blocked === 0,
        'Recorded Last Car audio produced decode or playback errors');
      return {favorite, narration: LCU.save.settings.narration, voices: LCU.save.settings.voices, audit: timeline};
    }
    if (app === 'LastCarUpright') {
      const state = await baseState(app, prior);
      require(prior.narration === false && LCU.save.settings.narration === false && LCU.save.settings.voices === prior.voices,
        'Fresh process did not restore imported narration preferences');
      return {...state, narration: false, voices: LCU.save.settings.voices, initialAudit: prior.audit};
    }
    return minerSaveState(prior);
  };
})();
