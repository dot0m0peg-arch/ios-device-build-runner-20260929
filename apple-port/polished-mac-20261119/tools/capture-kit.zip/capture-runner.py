import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
from zipfile import ZIP_DEFLATED, ZipFile

WRAPPER_SHA = "a1f468a45a4b5b063fb9875dad5c3ab8b640828869d23434ce73f2fd2c9d6387"
SESSION_SHA = "8ec09e12439c9c1228fb9dbf8cfda639100e1ddb817e7e4765fcff8c4f71b482"
ENTITLEMENTS_SHA = "c0e0afd6abe100386f5bc3ee241557a7b91c9ce59b8c1e99e962bceb49729cfb"


def hash_bytes(payload):
    return hashlib.sha256(payload).hexdigest()


def pack(audit, wrapper, output):
    changes = {
        "Sources/AppleGameApp.swift": (wrapper, WRAPPER_SHA),
        "Sources/GameSession.swift": (audit / "Sources/GameSession.swift", SESSION_SHA),
        "Apps/LastCarUpright/Mac.entitlements": (audit / "Apps/LastCarUpright/Mac.entitlements", ENTITLEMENTS_SHA),
    }
    with ZipFile(audit / "gameplay-source-overlay.zip") as base, ZipFile(output, "w", ZIP_DEFLATED) as target:
        for name in base.namelist():
            if name not in changes and name not in ("audit/RuntimeGameplay.swift", "audit/gameplay-runner.py", "audit/gameplay-probes.js"):
                target.writestr(name, base.read(name))
        for name, (file, expected) in changes.items():
            content = file.read_bytes()
            if hash_bytes(content) != expected:
                raise ValueError(f"Existing signed-wrapper component changed: {name}")
            target.writestr(name, content)
        for name in ("capture-runner.py", "RuntimeScreenshots.swift", "screenshot-scenes.js", "capture-acceptance.js"):
            target.write(audit / name, f"audit/{name}")
    print("Capture overlay SHA-256 " + hash_bytes(output.read_bytes()))
    print("Exact final privacy wrapper SHA-256 " + WRAPPER_SHA)


def prepare(root, app, scheme):
    spec = json.loads((root / "project.json").read_bytes())
    for field in ("targets", "schemes"):
        spec[field] = {scheme: spec[field][scheme]}
    (root / "project.json").write_text(json.dumps(spec))
    wrapper = root / "Sources/AppleGameApp.swift"
    assert hash_bytes(wrapper.read_bytes()) == WRAPPER_SHA
    assert hash_bytes((root / "Sources/GameSession.swift").read_bytes()) == SESSION_SHA
    before = ".task { game.start() }"
    old = wrapper.read_text()
    assert old.count(before) == 1
    wrapper.write_text(old.replace(before, ".task { game.start(); await RuntimeScreenshots.run(game.webView, problem: { game.problem }) }"))
    source = (root / "audit/RuntimeScreenshots.swift").read_text(encoding="utf-8-sig")
    js = "\n".join((root / "audit" / f).read_text(encoding="utf-8-sig") for f in ("screenshot-scenes.js", "capture-acceptance.js"))
    (root / "Sources/RuntimeScreenshots.swift").write_text(source.replace("__PROBE_SOURCE__", base64.b64encode(js.encode()).decode()))
    if scheme.endswith("-iOS"):
        build = root / "build-unsigned.sh"
        build.write_text(build.read_text().replace('generic/platform=iOS"', 'generic/platform=iOS Simulator"'))


def run(command, timeout=120, **args):
    return subprocess.run(command, check=True, timeout=timeout, **args)


def boot_device(model, root):
    table = json.loads(run(["xcrun", "simctl", "list", "devices", "available", "-j"], capture_output=True).stdout)["devices"]
    candidates = [
        (tuple(int(n) for n in key.rsplit(".iOS-", 1)[-1].split("-")), d)
        for key, items in table.items() if ".iOS-" in key
        for d in items if d["name"] == model and d.get("isAvailable")
    ]
    if not candidates:
        raise ValueError("Required screenshot simulator is unavailable: " + model)
    device = max(candidates, key=lambda item: item[0])[1]
    udid = device["udid"]
    if device["state"] != "Booted":
        run(["xcrun", "simctl", "boot", udid], timeout=90)
    readiness = root / "sim-readiness.png"
    deadline = time.monotonic() + 220
    while time.monotonic() < deadline:
        try:
            tasks = run(["xcrun", "simctl", "spawn", udid, "launchctl", "list"],
                        timeout=12, capture_output=True).stdout
            if b"com.apple.SpringBoard" in tasks:
                run(["xcrun", "simctl", "io", udid, "screenshot", str(readiness)],
                    timeout=15, capture_output=True)
                if readiness.stat().st_size > 4000:
                    readiness.unlink()
                    return udid
        except (subprocess.SubprocessError, OSError):
            time.sleep(3)
    subprocess.run(["xcrun", "simctl", "shutdown", udid], timeout=30, check=False)
    raise TimeoutError("SpringBoard and simulator screenshot service did not become ready: " + model)


def wait_process_exit(pid, maximum=14):
    if pid is None:
        return
    deadline = time.monotonic() + maximum
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return
        time.sleep(.25)
    import stat
    executable = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "command="], check=False, capture_output=True, text=True).stdout
    if "native screenshot sandbox" in executable:
        os.kill(pid, signal.SIGTERM)
    raise TimeoutError(f"Test app process {pid} remained after reporting termination")


def launch(product, bundle, device, root, output, prior=None):
    mode = "verify" if prior else "capture"
    stdout = root / f"{mode}-stdout.log"
    stderr = root / f"{mode}-stderr.log"
    args = ['--native-verify', json.dumps(prior, separators=(',', ':'))] if prior else []
    child = None
    if device:
        with stdout.open("wb") as out, stderr.open("wb") as err:
            child = subprocess.Popen(["xcrun", "simctl", "launch", "--console-pty",
                "--terminate-running-process", device, bundle, *args], stdout=out, stderr=err)
    else:
        stdout.touch()
        stderr.touch()
        run(["/usr/bin/open", "-n", "--stdout", str(stdout), "--stderr", str(stderr), str(product), "--args", *args], timeout=35)
    done = set()
    deadline = time.monotonic() + 290
    pid = None
    try:
        while time.monotonic() < deadline:
            contents = stdout.read_text(errors="replace")
            for line in contents.splitlines():
                line = line.strip()
                if line in done:
                    continue
                done.add(line)
                print(line, flush=True)
                if line.startswith("APPLE_CAPTURE_PID "):
                    pid = int(line.split()[1])
                if line.startswith("APPLE_CAPTURE_FRAME ") and device:
                    _, frame, label = line.split()
                    target = output / f"{frame}-{label}.png"
                    run(["xcrun", "simctl", "io", device, "screenshot", str(target)], timeout=17)
                elif line.startswith("APPLE_CAPTURE_FILE ") and not device:
                    _, frame, label, rectangle, ack_path, path = line.split(" ", 5)
                    own = Path(path).resolve()
                    acknowledgment = Path(ack_path).resolve()
                    if acknowledgment.parent != own.parent or not acknowledgment.name.startswith(f"display-{frame}-"):
                        raise ValueError("Independent capture acknowledgment escaped the screenshot folder")
                    own_directory = root / "own-process-comparison"
                    own_directory.mkdir(exist_ok=True)
                    shutil.copyfile(own, own_directory / f"{frame}-{label}.png")
                    target = output / f"{frame}-{label}.png"
                    request = subprocess.run(["/usr/sbin/screencapture","-x","-t","png","-R"+rectangle,str(target)],
                                             timeout=30,capture_output=True,text=True)
                    print(f"INDEPENDENT_DISPLAY_CAPTURE exit={request.returncode} rect={rectangle} {request.stderr.strip()}", flush=True)
                    if request.returncode or not target.is_file():
                        raise RuntimeError("Independent WindowServer capture produced no image")
                    acknowledgment.touch()
                elif line.startswith("APPLE_CAPTURE_ACCEPTANCE "):
                    value = json.loads(line.removeprefix("APPLE_CAPTURE_ACCEPTANCE "))
                    if not device:
                        wait_process_exit(pid)
                    return value
                elif line.startswith("APPLE_SCREENSHOTS_FAIL "):
                    raise RuntimeError(line)
            if child and child.poll() not in (None, 0):
                raise RuntimeError(f"simctl exited {child.returncode}: {stderr.read_text(errors='replace')[-2000:]}")
            time.sleep(.15)
        raise TimeoutError(f"{bundle} {mode} left no acceptance report; stderr: {stderr.read_text(errors='replace')[-1800:]}")
    finally:
        if child and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=10)


def manifest(output, app, model, result, error):
    from PIL import Image, ImageStat
    dimensions = (
        {(1440,900)} if model == "Mac" else {(2736,1260)} if model == "iPhone Air"
        else {(2752,2064),(2064,2752)}
    )
    findings = []
    for path in sorted(output.glob("*.png")):
        try:
            with Image.open(path) as picture:
                if picture.size not in dimensions:
                    raise ValueError(f"{path.name} rendered at {picture.size}; expected {sorted(dimensions)}")
                if "A" in picture.getbands() and picture.getchannel("A").getextrema() != (255,255):
                    raise ValueError(f"{path.name} contains transparent pixels")
                # Inspect unscaled central pixels for absent WebGL layers.
                width, height = picture.size
                rgb = picture.convert("RGB")
                region = rgb.crop((width//5,height//5,4*width//5,4*height//5))
                if max(ImageStat.Stat(region).stddev) < 5:
                    raise ValueError(f"{path.name} appears blank or missing the rendered field")
                if picture.mode != "RGB":
                    rgb.save(path, format="PNG")
                findings.append({"path": path.name, "width": width, "height": height,
                                 "sha256": hash_bytes(path.read_bytes())})
        except Exception as exc:
            print(str(exc), flush=True)
            path.rename(path.with_suffix(".rejected.png"))
    information = {"app": app, "device": model, "privacy_wrapper_sha256": WRAPPER_SHA,
                   "game_session_sha256": SESSION_SHA, "native_frames": findings,
                   "native_relaunch_acceptance": result, "error": error}
    (output / "manifest.json").write_text(json.dumps(information, indent=2))
    if not findings:
        raise RuntimeError("No accepted native screenshot")


def invoke(product, app, bundle, model):
    root = Path(os.environ["RUNNER_TEMP"])
    output = root / "captures"
    output.mkdir()
    device = None
    result, error = None, None
    try:
        if model != "Mac":
            device = boot_device(model, root)
            run(["xcrun", "simctl", "install", device, str(product)], timeout=70)
        original = launch(product, bundle, device, root, output)
        if device:
            subprocess.run(["xcrun", "simctl", "terminate", device, bundle], timeout=30, check=False, capture_output=True)
        result = launch(product, bundle, device, root, output, original)
    except Exception as exc:
        error = str(exc)
        print(error, flush=True)
    finally:
        if device:
            subprocess.run(["xcrun", "simctl", "shutdown", device], timeout=45, check=False)
    manifest(output, app, model, result, error)
    if error:
        raise RuntimeError(error)


if __name__ == "__main__":
    command, *args = sys.argv[1:]
    if command == "pack":
        pack(*(Path(value) for value in args))
    elif command == "prepare":
        prepare(Path(args[0]), *args[1:])
    elif command == "invoke":
        invoke(Path(args[0]), *args[1:])
    else:
        raise SystemExit("Expected pack, prepare or invoke")

