import CoreGraphics
import Foundation

let display = CGMainDisplayID()
let options = [kCGDisplayShowDuplicateLowResolutionModes as String: true] as CFDictionary
let modes = CGDisplayCopyAllDisplayModes(display, options) as? [CGDisplayMode] ?? []

func scale(_ mode: CGDisplayMode) -> Double {
    Double(mode.pixelWidth) / Double(max(1, mode.width))
}
func fits(_ mode: CGDisplayMode) -> Bool {
    let factor = scale(mode)
    return Double(mode.width) >= ceil(1440 / factor) + 20 &&
           Double(mode.height) >= ceil(900 / factor) + 100
}
func show(_ mode: CGDisplayMode) -> String {
    "\(mode.width)x\(mode.height) logical at \(scale(mode))x (\(mode.pixelWidth)x\(mode.pixelHeight) pixels)"
}
if let active = CGDisplayCopyDisplayMode(display), fits(active) {
    print("APPLE_CAPTURE_DISPLAY \(show(active)) existing mode")
    exit(0)
}

let choices = modes.filter(fits).sorted {
    ($0.pixelWidth * $0.pixelHeight) < ($1.pixelWidth * $1.pixelHeight)
}
for mode in choices {
    var transaction: CGDisplayConfigRef?
    guard CGBeginDisplayConfiguration(&transaction) == .success else { continue }
    if CGConfigureDisplayWithDisplayMode(transaction, display, mode, nil) != .success {
        CGCancelDisplayConfiguration(transaction)
        continue
    }
    if CGCompleteDisplayConfiguration(transaction, .forSession) == .success,
       let active = CGDisplayCopyDisplayMode(display), fits(active) {
        print("APPLE_CAPTURE_DISPLAY \(show(active)) selected for this runner session")
        exit(0)
    }
}
print("No Mac runner display mode can fit a native 1440x900 game viewport.")
for mode in modes.prefix(20) { print("APPLE_DISPLAY_AVAILABLE \(show(mode))") }
exit(1)
