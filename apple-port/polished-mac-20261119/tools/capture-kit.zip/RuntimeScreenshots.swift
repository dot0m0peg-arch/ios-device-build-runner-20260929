import Darwin
import Foundation
import WebKit

#if os(macOS)
import AppKit
import ScreenCaptureKit
#endif

@MainActor
enum RuntimeScreenshots {
    static func run(_ view: WKWebView, problem: @escaping () -> String?) async {
        do {
            guard let app = Bundle.main.object(forInfoDictionaryKey: "CFBundleExecutable") as? String else {
                throw CaptureFailure("No app executable name")
            }
            #if os(macOS)
            let window = try await sizedWindow(view)
            #endif
            if app == "QuicksilverPennies" || app == "Miner3D" {
                view.load(URLRequest(url: URL(string: "game-assets://local/index.html?debug")!))
            }
            var ready = false
            for _ in 0..<225 {
                if let problem = problem() { throw CaptureFailure(problem) }
                if (try? await view.evaluateJavaScript("document.readyState === 'complete' && document.title.length > 0")) as? Bool == true {
                    ready = true
                    break
                }
                try await Task.sleep(for: .milliseconds(200))
            }
            guard ready, let source = Data(base64Encoded: probeBase64) else {
                throw CaptureFailure("Gameplay script did not reach the rendered page")
            }
            _ = try await view.evaluateJavaScript(String(decoding: source, as: UTF8.self))
            report("APPLE_CAPTURE_PID \(ProcessInfo.processInfo.processIdentifier)")
            let args = ProcessInfo.processInfo.arguments
            let prior: Any
            if let index = args.firstIndex(of: "--native-verify"), args.indices.contains(index + 1) {
                prior = try JSONSerialization.jsonObject(with: Data(args[index + 1].utf8))
            } else {
                prior = NSNull()
            }
            let count = prior is NSNull ? (app == "MyPetSnake" ? 3 : 2) : 0
            for index in 0..<count {
                let frame = index + 1
                let result = try await view.callAsyncJavaScript(
                    "return await window.appleScreenshotScene(app, frame);",
                    arguments: ["app": app, "frame": frame], in: nil, contentWorld: .page)
                guard let label = result as? String else { throw CaptureFailure("Missing gameplay capture label") }
                try await Task.sleep(for: .milliseconds(750))
                #if os(macOS)
                let output = FileManager.default.temporaryDirectory
                    .appendingPathComponent("native-game-\(frame).png")
                window.center()
                NSApplication.shared.activate(ignoringOtherApps: true)
                window.makeKeyAndOrderFront(nil)
                window.orderFrontRegardless()
                try await Task.sleep(for: .milliseconds(1100))
                let page = try await view.evaluateJavaScript("document.visibilityState") as? String ?? "unknown"
                let visible = window.occlusionState.contains(.visible)
                report("APPLE_CAPTURE_VISIBILITY active=\(NSApplication.shared.isActive) occlusionVisible=\(visible) onActiveSpace=\(window.isOnActiveSpace) document=\(page)")
                guard visible && window.isOnActiveSpace && page == "visible",
                      let screen = window.screen, screen.backingScaleFactor == 1,
                      let number = screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber
                else { throw CaptureFailure("Game window is not visible on an active 1x native display") }
                try await screenshot(view, window: window, to: output)
                let viewFrame = window.convertToScreen(view.convert(view.bounds, to: nil))
                let display = CGDisplayBounds(CGDirectDisplayID(number.uint32Value))
                let x = Int((display.minX + viewFrame.minX - screen.frame.minX).rounded())
                let y = Int((display.minY + screen.frame.maxY - viewFrame.maxY).rounded())
                let rectangle = "\(x),\(y),\(desiredWidth),\(desiredHeight)"
                let acknowledgment = output.deletingLastPathComponent()
                    .appendingPathComponent("display-\(frame)-\(UUID().uuidString).ack")
                report("APPLE_CAPTURE_FILE \(frame) \(label) \(rectangle) \(acknowledgment.path) \(output.path)")
                var acquired = false
                for _ in 0..<240 {
                    if FileManager.default.fileExists(atPath: acknowledgment.path) {
                        acquired = true
                        break
                    }
                    try await Task.sleep(for: .milliseconds(200))
                }
                guard acquired else { throw CaptureFailure("Independent display capture was not acknowledged") }
                try? FileManager.default.removeItem(at: acknowledgment)
                #else
                report("APPLE_CAPTURE_FRAME \(frame) \(label)")
                try await Task.sleep(for: .seconds(5))
                #endif
            }
            let acceptance = try await view.callAsyncJavaScript(
                "return JSON.stringify(await window.appleScreenshotState(app, prior));",
                arguments: ["app": app, "prior": prior], in: nil, contentWorld: .page)
            guard let saved = acceptance as? String else { throw CaptureFailure("Missing game-state proof") }
            try await Task.sleep(for: .milliseconds(1300))
            report("APPLE_CAPTURE_ACCEPTANCE \(saved)")
            #if os(macOS)
            NSApplication.shared.terminate(nil)
            #else
            exit(EXIT_SUCCESS)
            #endif
        } catch {
            report("APPLE_SCREENSHOTS_FAIL \(error)")
            #if os(macOS)
            NSApplication.shared.terminate(nil)
            #else
            exit(EXIT_FAILURE)
            #endif
        }
    }

    #if os(macOS)
    private static let desiredWidth = 1440
    private static let desiredHeight = 900

    private static func sizedWindow(_ view: WKWebView) async throws -> NSWindow {
        for _ in 0..<75 {
            if let window = view.window, window.isVisible, window.screen != nil {
                let scale = window.backingScaleFactor
                let target = NSSize(width: CGFloat(desiredWidth) / scale, height: CGFloat(desiredHeight) / scale)
                window.setContentSize(target)
                window.makeKeyAndOrderFront(nil)
                for _ in 0..<6 {
                    try await Task.sleep(for: .milliseconds(350))
                    let actual = window.convertToScreen(view.convert(view.bounds, to: nil)).size
                    let offset = NSSize(width: target.width - actual.width, height: target.height - actual.height)
                    if abs(offset.width) < 0.24 && abs(offset.height) < 0.24 { return window }
                    let native = window.contentRect(forFrameRect: window.frame).size
                    print("APPLE_CAPTURE_VIEWPORT observed=\(actual) native=\(native) measuredOffset=\(offset)")
                    window.setContentSize(NSSize(width: native.width + offset.width, height: native.height + offset.height))
                }
                throw CaptureFailure("Native WebView did not settle at the measured target size")
            }
            try await Task.sleep(for: .milliseconds(100))
        }
        throw CaptureFailure("The application never attached to its native Mac window")
    }

    private static func screenshot(_ view: WKWebView, window: NSWindow, to url: URL) async throws {
        guard #available(macOS 14.4, *) else { throw CaptureFailure("Native own-window capture needs macOS 14.4") }
        let owned = try await SCShareableContent.currentProcess
        guard let source = owned.windows.first(where: { $0.windowID == CGWindowID(window.windowNumber) }) else {
            throw CaptureFailure("Native game window was unavailable to ScreenCaptureKit")
        }
        let filter = SCContentFilter(desktopIndependentWindow: source)
        let scale = CGFloat(filter.pointPixelScale)
        guard scale > 0 else { throw CaptureFailure("ScreenCaptureKit reported invalid backing scale") }
        let options = SCStreamConfiguration()
        options.ignoreShadowsSingleWindow = true
        options.ignoreGlobalClipSingleWindow = true
        options.scalesToFit = false
        options.showsCursor = false
        options.shouldBeOpaque = true
        options.width = Int((window.frame.width * scale).rounded())
        options.height = Int((window.frame.height * scale).rounded())
        let image = try await SCScreenshotManager.captureImage(contentFilter: filter, configuration: options)
        let content = window.convertToScreen(view.convert(view.bounds, to: nil))
        let pixelWidth = Int((content.width * scale).rounded())
        let pixelHeight = Int((content.height * scale).rounded())
        guard pixelWidth == desiredWidth && pixelHeight == desiredHeight else {
            throw CaptureFailure("Game viewport rendered at \(pixelWidth)×\(pixelHeight), expected 1440×900")
        }
        let selected: CGImage
        if image.width == pixelWidth && image.height == pixelHeight {
            selected = image
        } else {
            let rect = CGRect(x: ((content.minX - window.frame.minX) * scale).rounded(),
                              y: ((window.frame.maxY - content.maxY) * scale).rounded(),
                              width: CGFloat(pixelWidth), height: CGFloat(pixelHeight))
            guard image.width == options.width, image.height == options.height,
                  let cropped = image.cropping(to: rect), cropped.width == pixelWidth, cropped.height == pixelHeight else {
                throw CaptureFailure("Native compositor returned unexpected window geometry \(image.width)×\(image.height)")
            }
            selected = cropped
        }
        guard let png = NSBitmapImageRep(cgImage: selected).representation(using: .png, properties: [:]) else {
            throw CaptureFailure("Native compositor screenshot could not be encoded")
        }
        try png.write(to: url, options: .atomic)
    }
    #endif

    private static func report(_ message: String) {
        FileHandle.standardOutput.write(Data((message + "\n").utf8))
    }

    static let probeBase64 = "__PROBE_SOURCE__"

    struct CaptureFailure: LocalizedError {
        var errorDescription: String?
        init(_ message: String) { errorDescription = message }
    }
}

