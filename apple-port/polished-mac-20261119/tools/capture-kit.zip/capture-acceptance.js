(() => {
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const get = sel => [...document.querySelectorAll(sel)].find(el => el.getClientRects().length && !el.disabled);
  const save = key => JSON.parse(localStorage.getItem(key) || 'null');
  async function wait(label, accept, timeout = 32000) {
    const until = performance.now() + timeout;
    do {
      const value = accept();
      if (value) return value;
      await sleep(100);
    } while (performance.now() < until);
    throw Error('Acceptance timed out: ' + label);
  }
  async function click(selector) {
    const control = await wait(selector, () => get(selector));
    control.click();
  }
  function require(ok, label) { if (!ok) throw Error(label); }
  const checks = {
    async MyPetSnake(prior) {
      await wait('running iOS game', () => window.sb?.ready);
      if (!prior) await click('[data-pet-action="rabbit"][data-pet-value="dutch"]');
      await wait('Dutch Tripo model', () => {
        const pet = window.sb.scene.getObjectByName('Bunny');
        return pet?.visible && pet.userData?.source === 'tripo' && pet.userData?.breed === 'dutch';
      });
      const saved = save('slime-buddy.habitats.v1');
      require(saved?.mode === 'bunny' && saved.rabbit === 'dutch', 'No saved Dutch habitat');
      return {rabbit: saved.rabbit, frames: window.sb.stats.frames};
    },
    async Timbersack(prior) {
      const logs = await wait('loaded native workshop and game save', () => {
        const saved = save('timbersack-build-v1');
        return get('#workspace') && saved?.logs?.length && saved.logs;
      });
      require(logs.some(log => log.n === 4), 'Long log was not present');
      const fields = ['n','r','x','z','y','id','span','asset'];
      const preserved = !prior || (Array.isArray(prior.logs) && prior.logs.length === logs.length &&
        logs.every((entry, index) => fields.every(field => (entry[field] ?? null) === (prior.logs[index][field] ?? null))));
      require(preserved, 'Relaunch restored different piece values: '+JSON.stringify({expected:prior?.logs,actual:logs}));
      require(document.querySelector('#saveWarning').hidden, 'Workshop reported a write failure');
      return {logs};
    },
    async LastCarUpright(prior) {
      const game = await wait('native Last Car engine', () => window.LCU?.api && window.LCU);
      if (!prior) {
        await click('[data-a=fav]');
        require(window.appleScreenshotH2HPlayed === true, 'Did not reach the result of a Head to Head round');
      }
      const favorite = await wait('game-authored Garage favorite',
        () => Object.entries(game.save.cars).find(([, car]) => car.favorite)?.[0]);
      require(!prior || favorite === prior.favorite, 'Relaunch restored different Garage state');
      return {favorite};
    },
    async Miner3D(prior) {
      const miner = await wait('native Miner build debug observer', () => window.MINER);
      if (prior) {
        await wait('Continue button', () => get('#tPlay')?.textContent === 'Continue');
        await click('#tPlay');
        await wait('live restored valley', () => miner.gameState === 'play' && miner.P);
        require(miner.G.seed === prior.seed && Math.hypot(miner.P.x - prior.player.x, miner.P.z - prior.player.z) < .15,
          'Continue restored a different valley or player location');
        return {seed: miner.G.seed, player: {x: miner.P.x, z: miner.P.z}};
      }
      await wait('live valley', () => miner.gameState === 'play' && miner.P);
      // Use the actual Build toggle to restore walking mode if the second photo is overhead.
      if (get('#viewLabel')?.textContent?.trim() === 'Walk') await click('#bView');
      const start = {x: miner.P.x, z: miner.P.z};
      const key = (type, k, code) => window.dispatchEvent(new KeyboardEvent(type, {key: k, code, bubbles:true, cancelable:true}));
      for (const [k, code] of [['d','KeyD'], ['w','KeyW'], ['a','KeyA']]) {
        key('keydown', k, code);
        try { await sleep(1100); }
        finally { key('keyup', k, code); }
        if (Math.hypot(miner.P.x - start.x, miner.P.z - start.z) > 1) break;
      }
      require(Math.hypot(miner.P.x - start.x, miner.P.z - start.z) > 1, 'WASD did not move the miner');
      await click('#bMenu');
      await click('#sheetTabs [data-tab=set]');
      await click('#sheetBody [data-act=save]');
      const record = await wait('game-authored world and moved player', () => {
        const item = save('miner3.save');
        return item?.world && Math.hypot(item.player.x-start.x,item.player.z-start.z)>1 && item;
      });
      return {seed: record.seed, player: record.player};
    },
    async QuicksilverPennies(prior) {
      const workshop = await wait('released native workshop', () => window.qs?.state && window.qs);
      if (!prior) require(workshop.saveNow(), 'The workshop did not save its pour');
      const record = save('quicksilver-pennies.save');
      const state = workshop.state();
      require(record?.station === 'bench' && record.blobs?.tray?.length && state.trayMl > .2, 'No saved silver in tray');
      require(!prior || (workshop.loadedSave && Math.abs(state.trayMl-prior.trayMl) < .025), 'Relaunch did not restore poured silver');
      return {trayMl: state.trayMl, station: record.station};
    }
  };
  window.appleScreenshotState = (app, prior = null) => checks[app](prior);
})();

