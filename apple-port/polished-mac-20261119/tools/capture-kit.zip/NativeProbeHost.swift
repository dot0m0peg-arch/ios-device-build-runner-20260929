import AppKit
import WebKit

@MainActor
final class NativeProbeHost: NSObject, WKScriptMessageHandlerWithReply {
    private weak var view: WKWebView?

    static func install(_ view: WKWebView, script: String) {
        let content = view.configuration.userContentController
        let handler = NativeProbeHost()
        handler.view = view
        content.addScriptMessageHandler(handler, contentWorld: .page, name: "nativeMouse")
        content.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: true))
    }

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage,
        replyHandler: @escaping @MainActor @Sendable (Any?, String?) -> Void
    ) {
        guard message.frameInfo.isMainFrame, message.frameInfo.request.url?.scheme == "game-assets",
              let view, let window = view.window
        else { replyHandler(nil, "Native probe requires the main game window"); return }
        if message.body as? String == "background" {
            NSApplication.shared.hide(nil)
            Task { @MainActor in
                try? await Task.sleep(for: .milliseconds(2000))
                NSApplication.shared.unhide(nil)
                NSApplication.shared.activate(ignoringOtherApps: true)
                window.makeKeyAndOrderFront(nil)
            }
            replyHandler(true, nil)
            return
        }
        guard let input = message.body as? [String: Double],
              let x = input["x"], let y = input["y"], let width = input["width"], let height = input["height"],
              width.isFinite, height.isFinite, width > 0, height > 0,
              x > 0, x < width, y > 0, y < height, window.isOnActiveSpace,
              window.occlusionState.contains(.visible)
        else { replyHandler(nil, "Invalid game viewport or native input coordinates"); return }
        let bounds = view.bounds
        let localX = bounds.minX + CGFloat(x / width) * bounds.width
        let yFromTop = CGFloat(y / height) * bounds.height
        let localY = view.isFlipped ? bounds.minY + yFromTop : bounds.maxY - yFromTop
        let point = view.convert(NSPoint(x: localX, y: localY), to: nil)
        let rawHold = input["hold"] ?? 0
        guard rawHold.isFinite, rawHold >= 0, rawHold <= 1500
        else { replyHandler(nil, "Invalid native pointer-down duration"); return }
        NSApplication.shared.activate(ignoringOtherApps: true)
        window.makeKeyAndOrderFront(nil)
        func send(_ kind: NSEvent.EventType) -> Bool {
            guard let event = NSEvent.mouseEvent(with: kind, location: point, modifierFlags: [],
                  timestamp: ProcessInfo.processInfo.systemUptime,
                  windowNumber: window.windowNumber, context: nil,
                  eventNumber: 0, clickCount: kind == .mouseMoved ? 0 : 1,
                  pressure: kind == .leftMouseDown ? 1 : 0)
            else { return false }
            window.sendEvent(event)
            return true
        }
        guard send(.mouseMoved), send(.leftMouseDown)
        else { replyHandler(nil, "AppKit could not create the native game event"); return }
        Task { @MainActor in
            if rawHold > 0 { try? await Task.sleep(for: .milliseconds(Int(rawHold))) }
            let sent = send(.leftMouseUp)
            replyHandler(sent ? true : nil, sent ? nil : "Could not release the native pointer")
        }
    }
}
